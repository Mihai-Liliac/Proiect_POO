﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using Hotel_Self_Check_in;
using HotelSelfCheck;

namespace AppUI
{
    public partial class AdminUI : Window
    {
        private Administrator admin;
        private HotelData data;
        private ObservableCollection<Room> rooms;

        public AdminUI()
        {
            InitializeComponent();

            data = DataStore.Load();

            // Folosim primul Admin din listă
            admin = data.Users.OfType<Administrator>().FirstOrDefault();
            if (admin == null)
            {
                MessageBox.Show("Nu există administrator!");
                this.Close();
            }

            rooms = new ObservableCollection<Room>(data.Rooms);
            RoomsList.ItemsSource = rooms;
        }

        private void AddRoom_Click(object sender, RoutedEventArgs e)
        {
            int newNumber = data.Rooms.Max(r => r.Number) + 1;
            var room = new Room(newNumber, "Single", RoomStatus.Libera, new List<string> { "WiFi", "TV" });

            admin.CreateRoom(room);
            data.Rooms.Add(room);
            rooms.Add(room);
            DataStore.Save(data);

            MessageBox.Show($"Camera {room.Number} a fost adăugată.");
        }

        private void DeleteRoom_Click(object sender, RoutedEventArgs e)
        {
            if (RoomsList.SelectedItem is Room room)
            {
                admin.DeleteRoom(room.Number);
                data.Rooms.Remove(room);
                rooms.Remove(room);
                DataStore.Save(data);

                MessageBox.Show($"Camera {room.Number} a fost ștearsă.");
            }
            else
            {
                MessageBox.Show("Selectează o cameră!");
            }
        }
    }
}