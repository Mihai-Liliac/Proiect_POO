﻿using System.Linq;
using System.Windows;
using Hotel_Self_Check_in;

namespace AppUI
{
    public partial class LoginView : Window
    {
        private HotelData data;

        public LoginView()
        {
            InitializeComponent();
            data = DataStore.Load();

            // Creează Admin și Client de test dacă nu există
            if (!data.Users.OfType<Administrator>().Any())
            {
                data.Users.Add(new Administrator(1, "admin", "admin123"));
            }

            if (!data.Users.OfType<Client>().Any())
            {
                data.Users.Add(new Client(2, "client", "1234"));
            }

            DataStore.Save(data);
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            var user = data.Users.FirstOrDefault(u =>
                u.Username == UsernameBox.Text &&
                u.Password == PasswordBox.Password);

            if (user == null)
            {
                MessageBox.Show("Username sau parolă greșite");
                return;
            }

            Window nextWindow;
            if (user.Type == UserType.Admin)
                nextWindow = new AdminUI();
            else
                nextWindow = new ClientUI(user as Client);

            nextWindow.Show();
            this.Close();
        }
    }
}