﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using Hotel_Self_Check_in;

namespace AppUI
{
    public partial class ClientUI : Window
    {
        private Client currentClient;
        private HotelData data;
        private ObservableCollection<Room> availableRooms;

        public ClientUI(Client client)
        {
            InitializeComponent();

            if (client == null)
            {
                MessageBox.Show("Client invalid!");
                Close();
                return;
            }

            currentClient = client;

            // Încarcă datele
            data = DataStore.Load() ?? new HotelData();

            if (data.Rooms == null)
                data.Rooms = new List<Room>();

            if (currentClient.Reservations == null)
                currentClient.Reservations = new List<Reservation>();

            if (data.Reservations == null)
                data.Reservations = new List<Reservation>();

            // Inițializează lista de camere disponibile
            availableRooms = new ObservableCollection<Room>(
                data.Rooms.Where(r => r.Status == RoomStatus.Libera)
            );

            RoomsList.ItemsSource = availableRooms;
        }

        private void Reserve_Click(object sender, RoutedEventArgs e)
        {
            if (RoomsList.SelectedItem is Room room)
            {
                try
                {
                    currentClient.CreateReservation(room, DateTime.Today, DateTime.Today.AddDays(2));

                    // Adaugă rezervarea în date
                    data.Reservations.Add(currentClient.Reservations.Last());
                    DataStore.Save(data);

                    availableRooms.Remove(room);
                    MessageBox.Show($"Rezervarea camerei {room.Number} a fost realizată.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Eroare la rezervare: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Selectează o cameră!");
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            var reservation = currentClient.Reservations.LastOrDefault(r => r.Status == ReservationStatus.Activa);

            if (reservation == null)
            {
                MessageBox.Show("Nu există rezervări active!");
                return;
            }

            try
            {
                var room = data.Rooms.FirstOrDefault(r => r.Number == reservation.RoomNumber);
                if (room == null)
                {
                    MessageBox.Show("Camera rezervată nu mai există!");
                    return;
                }

                currentClient.CancelReservation(reservation, room);
                DataStore.Save(data);

                availableRooms.Add(room);
                MessageBox.Show($"Rezervarea camerei {room.Number} a fost anulată.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Eroare la anulare: " + ex.Message);
            }
        }

        private void History_Click(object sender, RoutedEventArgs e)
        {
            var history = currentClient.Reservations
                .Where(r => r.Status == ReservationStatus.Finalizata)
                .OrderBy(r => r.From)
                .ToList();

            if (!history.Any())
            {
                MessageBox.Show("Nu există rezervări finalizate.");
                return;
            }

            string message = "Istoric rezervări finalizate:\n";
            foreach (var r in history)
            {
                message += $"Camera {r.RoomNumber}: {r.From:dd/MM/yyyy} - {r.To:dd/MM/yyyy}\n";
            }

            MessageBox.Show(message, "Istoric Rezervări");
        }
    }
}
