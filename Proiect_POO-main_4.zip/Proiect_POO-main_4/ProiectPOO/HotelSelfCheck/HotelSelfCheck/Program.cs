﻿using System;
using System.Collections.Generic;
using AppUI;
using Hotel_Self_Check_in;

namespace HotelSelfCheck
{
    class Program
    {
        static void Main(string[] args)
        {
            // Încarcă datele existente sau creează altele noi
            HotelData data = DataStore.Load();

            // Creează utilizatori de test dacă nu există
            if (!data.Users.Any())
            {
                var admin = new Administrator(1, "admin", "14dsf");
                var client = new Client(2, "client", "2rtg");

                data.Users.Add(admin);
                data.Users.Add(client);

                // Creează camere
                var room1 = new Room(101, "Single", RoomStatus.Libera, new List<string> { "WiFi", "TV" });
                var room2 = new Room(102, "Double", RoomStatus.Libera, new List<string> { "WiFi", "TV", "MiniBar" });

                admin.CreateRoom(room1);
                admin.CreateRoom(room2);

                data.Rooms.Add(room1);
                data.Rooms.Add(room2);

                // Creează rezervări
                client.CreateReservation(room1, DateTime.Today, DateTime.Today.AddDays(3));
                data.Reservations.AddRange(client.Reservations);

                // Salvează tot
                DataStore.Save(data);

                Console.WriteLine("Date inițiale salvate cu succes!");
            }
            else
            {
                Console.WriteLine("Date existente găsite.");
            }

            Console.WriteLine("Apasă orice tastă pentru a ieși...");
            Console.ReadKey();
        }
    }
}