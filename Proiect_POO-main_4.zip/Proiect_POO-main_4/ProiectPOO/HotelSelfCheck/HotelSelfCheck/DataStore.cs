﻿using System;
using System.IO;
using System.Text.Json;
using Hotel_Self_Check_in;

namespace AppUI
{
    public static class DataStore
    {
        private static readonly string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "hotel.Data.json");

        public static void Save(HotelData data)
        {
            var options = new JsonSerializerOptions { WriteIndented = true };
            string json = JsonSerializer.Serialize(data, options);
            File.WriteAllText(filePath, json);
        }

        public static HotelData Load()
        {
            if (!File.Exists(filePath))
                return new HotelData();

            string json = File.ReadAllText(filePath);
            return JsonSerializer.Deserialize<HotelData>(json) ?? new HotelData();
        }
    }
}