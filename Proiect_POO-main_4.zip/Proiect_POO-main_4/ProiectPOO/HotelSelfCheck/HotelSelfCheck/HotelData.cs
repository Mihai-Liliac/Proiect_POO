﻿using System.Collections.Generic;

namespace Hotel_Self_Check_in
{
    public class HotelData
    {
        public List<User> Users { get; set; } = new List<User>();
        public List<Room> Rooms { get; set; } = new List<Room>();
        public List<Reservation> Reservations { get; set; } = new List<Reservation>();
    }
}