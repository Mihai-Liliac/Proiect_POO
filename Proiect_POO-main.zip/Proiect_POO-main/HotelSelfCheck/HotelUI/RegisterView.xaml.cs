﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;
using HotelSelfCheck;

namespace HotelUI
{
    public partial class RegisterView : Window
    {
        private HotelSelfCheck.HotelData _hotelData;

        public RegisterView(HotelSelfCheck.HotelData hotelData)
        {
            InitializeComponent();
            _hotelData = hotelData;
        }

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            if (e.ButtonState == MouseButtonState.Pressed) 
                this.DragMove();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox tb = sender as TextBox;
            if (tb == null) return;

            var placeholder = (TextBlock)tb.Template.FindName("placeholder", tb);
            if (placeholder != null)
            {
                placeholder.Visibility = (tb.Text.Length > 0) ? Visibility.Collapsed : Visibility.Visible;
            }
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            PasswordBox pb = sender as PasswordBox;
            if (pb == null) return;

            var placeholder = (TextBlock)pb.Template.FindName("placeholder", pb);
            if (placeholder != null)
            {
                placeholder.Visibility = (pb.Password.Length > 0) ? Visibility.Collapsed : Visibility.Visible;
            }
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameBox.Text.Trim();
            string password = PasswordBox.Password;
            string confirmPassword = ConfirmPasswordBox.Password;

            // Validări
            if (string.IsNullOrEmpty(username) || 
                string.IsNullOrEmpty(password) || string.IsNullOrEmpty(confirmPassword))
            {
                ShowError("Vă rugăm să completați toate câmpurile!");
                return;
            }

            if (username.Length < 3)
            {
                ShowError("Username-ul trebuie să aibă minim 3 caractere!");
                return;
            }

            if (password.Length < 4)
            {
                ShowError("Parola trebuie să aibă minim 4 caractere!");
                return;
            }

            if (password != confirmPassword)
            {
                ShowError("Parolele nu coincid!");
                return;
            }

            // Verifică dacă username-ul există deja
            if (_hotelData.Users.Any(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase)))
            {
                ShowError("Username-ul este deja folosit!");
                return;
            }

            try
            {
                // Determină tipul de cont
                int selectedIndex = AccountTypeBox.SelectedIndex;
                UserType userType = selectedIndex == 1 ? UserType.Admin : UserType.Client;
                
                // Creează ID-ul unic
                int newId = _hotelData.Users.Count > 0 ? _hotelData.Users.Max(u => u.Id) + 1 : 1;
                
                // Creează utilizatorul în funcție de tipul ales
                User newUser;
                if (userType == UserType.Admin)
                {
                    newUser = new Administrator(newId, username, password);
                }
                else
                {
                    newUser = new Client(newId, username, password);
                }
                
                _hotelData.Users.Add(newUser);
                
                // Salvează datele
                HotelSelfCheck.DataStore.Save(_hotelData);

                // Mesaj de succes
                string accountTypeName = userType == UserType.Admin ? "Administrator" : "Client";
                MessageBox.Show($"Cont creat cu succes!\nTip: {accountTypeName}\nBun venit, {username}!", 
                    "Înregistrare reușită", 
                    MessageBoxButton.OK, 
                    MessageBoxImage.Information);

                // Închide fereastra de înregistrare
                this.Close();
            }
            catch (Exception ex)
            {
                ShowError($"Eroare la crearea contului: {ex.Message}");
            }
        }

        private void BackToLogin_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ShowError(string message)
        {
            ErrorText.Text = message;
            ErrorBorder.Visibility = Visibility.Visible;

            // Animație shake
            Storyboard shake = (Storyboard)this.Resources["ShakeAnimation"];
            if (shake != null)
            {
                shake.Begin(MainCard);
            }
        }
    }
}