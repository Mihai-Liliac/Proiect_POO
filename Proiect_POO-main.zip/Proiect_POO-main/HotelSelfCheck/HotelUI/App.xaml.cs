﻿using System.Windows;

namespace HotelUI
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            new LoginView().Show();
        }
    }
}