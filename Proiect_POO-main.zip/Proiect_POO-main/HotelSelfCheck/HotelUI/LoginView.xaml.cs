﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;
using HotelSelfCheck;

namespace HotelUI
{
    public partial class LoginView : Window
    {
        private HotelSelfCheck.HotelData hotelData;

        public LoginView()
        {
            InitializeComponent();
            hotelData = HotelSelfCheck.DataStore.Load(); // Încarcă utilizatorii
        }

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            if (e.ButtonState == MouseButtonState.Pressed) this.DragMove();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e) => Application.Current.Shutdown();

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox tb = sender as TextBox;
            if (tb == null) return;

            var placeholder = (TextBlock)tb.Template.FindName("placeholder", tb);
            if (placeholder != null)
            {
                placeholder.Visibility = (tb.Text.Length > 0) ? Visibility.Collapsed : Visibility.Visible;
            }
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            PasswordBox pb = sender as PasswordBox;
            if (pb == null) return;
            var placeholder = (TextBlock)pb.Template.FindName("placeholder", pb);
            if (placeholder != null) placeholder.Visibility = (pb.Password.Length > 0) ? Visibility.Collapsed : Visibility.Visible;
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            string user = UsernameBox.Text.Trim();
            string pass = PasswordBox.Password;

            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pass))
            {
                ShowError("Vă rugăm să introduceți toate datele!");
                return;
            }

            var existingUser = hotelData.Users.FirstOrDefault(u => u.Username == user && u.Password == pass);
            if (existingUser != null)
            {
                if (existingUser.Type == UserType.Admin)
                {
                    new AdminView().Show();
                    this.Close();
                }
                else
                {
                    new UserView().Show();
                    this.Close();
                }
            }
            else
            {
                ShowError("Utilizator sau parolă incorectă!");
            }
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            new RegisterView(hotelData).Show();
        }

        private void ShowError(string message)
        {
            ErrorText.Text = message;
            ErrorBorder.Visibility = Visibility.Visible;
            Storyboard shake = (Storyboard)this.Resources["ShakeAnimation"];
            shake.Begin(MainCard);
        }
    }
}