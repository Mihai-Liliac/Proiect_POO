﻿using System.Windows;

namespace HotelUI;

/// <summary>
///     Interaction logic for App.xaml
/// </summary>
public partial class App : Application
{
}