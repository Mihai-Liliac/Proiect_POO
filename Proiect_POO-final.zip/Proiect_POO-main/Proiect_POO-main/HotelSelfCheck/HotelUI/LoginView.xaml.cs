﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;

namespace HotelUI;

public partial class LoginView : Window
{
    public LoginView()
    {
        InitializeComponent();
    }

    protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
    {
        if (e.ButtonState == MouseButtonState.Pressed) DragMove();
    }

    private void CloseButton_Click(object sender, RoutedEventArgs e)
    {
        Application.Current.Shutdown();
    }

    private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
    {
        var pb = sender as PasswordBox;
        if (pb == null) return;
        var template = pb.Template;
        var placeholder = (TextBlock)template.FindName("placeholder", pb);
        if (placeholder != null)
            placeholder.Visibility = pb.Password.Length > 0 ? Visibility.Collapsed : Visibility.Visible;
    }

    private void Login_Click(object sender, RoutedEventArgs e)
    {
        var data = DataStore.Load();
        var user = UsernameBox.Text.Trim();
        var pass = PasswordBox.Password;

        if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pass))
        {
            ShowError("Please enter your credentials!");
            return;
        }

        var foundUser = data.Users.FirstOrDefault(u => u.Username == user && u.Password == pass);

        if (foundUser != null)
        {
            if (foundUser.Role == "Admin") new AdminView().Show();
            else new UserView(foundUser.Username).Show();
            Close();
        }
        else
        {
            ShowError("Invalid username or password!");
        }
    }

    private void OpenRegister_Click(object sender, RoutedEventArgs e)
    {
        new RegisterView().Show();
        Close();
    }

    private void ShowError(string message)
    {
        ErrorText.Text = message;
        ErrorBorder.Visibility = Visibility.Visible;

        var shake = (Storyboard)Resources["ShakeAnimation"];
        if (shake != null) shake.Begin(MainCard);
    }
}