﻿namespace HotelSelfCheck;

internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
        //Cam gol (Pornim din HotelUI)
    }
}