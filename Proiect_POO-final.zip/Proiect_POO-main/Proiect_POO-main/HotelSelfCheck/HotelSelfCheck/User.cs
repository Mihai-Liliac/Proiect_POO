namespace HotelSelfCheck;
//Clasa mostenita de Administrator si Client. prezinta date comune
public class User
{
    public User(int id, string username, string password, UserType type)
    {
        Id = id;
        Username = username;
        Password = password;
        Type = type;
    }

    public int Id { get; private set; }
    public string Username { get; private set; }
    public string Password { get; private set; }

    public UserType Type { get; private set; }
}