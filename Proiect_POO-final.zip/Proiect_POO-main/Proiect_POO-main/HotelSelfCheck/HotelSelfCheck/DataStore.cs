using System.Text.Json;

namespace HotelSelfCheck;

public class DataStore
{
    //Clasa pentru salvarea si incarcarea datelor in fisier de tip json
    private static readonly string filePath = "hotel.Data.json";
    
    //Functie de salvare prin serializare
    public static void Save(HotelData data)
    {
        var options = new JsonSerializerOptions { WriteIndented = true };
        var json = JsonSerializer.Serialize(data, options);
        File.WriteAllText(filePath, json);
    }
    //Functiee de incarcare a datelor din fisierul json prin deserializare
    public static HotelData Load()
    {
        try
        {
            //Daca fisierul nu exista, se creeaza
            if (!File.Exists(filePath))
            {
                var newData = new HotelData();
                newData.InitializeDefaults();
                return newData;
            }

            var json = File.ReadAllText(filePath);
            var data = JsonSerializer.Deserialize<HotelData>(json);
            
            if (data == null) data = new HotelData(); //Protectie impotriva deserializarii null

            data.InitializeDefaults();
            return data;
        }
        //Daca apar erori, returneaza niste valori implicite
        catch (Exception)
        {
            var fallbackData = new HotelData();
            fallbackData.InitializeDefaults();
            return fallbackData;
        }
    }
}