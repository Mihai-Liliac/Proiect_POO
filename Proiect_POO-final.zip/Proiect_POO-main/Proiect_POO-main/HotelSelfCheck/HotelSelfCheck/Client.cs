namespace HotelSelfCheck;

public class Client : User
{
    private readonly List<Room> availableRooms = new();

    public Client(int id, string username, string password) : base(id, username, password, UserType.Client)
    {
    }

    public List<Reservation> Reservations { get; } = new();
    //Functie de gasire a camerelor libere. Daca acestea exista, se vor afisa
    public List<Room> SearchAvailableRooms(List<Room> rooms, DateTime from, DateTime to, string type = null,
        List<string> facilities = null)
    {
        foreach (var room in rooms)
        {
            if (room.Status != RoomStatus.Libera)
                continue;

            if (!string.IsNullOrEmpty(type) && room.Type != type)
                continue;

            if (facilities != null && facilities.Count > 0)
            {
                var allFacilitiesExist = true;
                foreach (var f in facilities)
                    if (!room.Facilities.Contains(f))
                    {
                        allFacilitiesExist = false;
                        break;
                    }

                if (!allFacilitiesExist)
                    continue;
            }

            availableRooms.Add(room);
        }

        return availableRooms;
    }
    //Functie de creeare a unei rezervari
    public void CreateReservation(Room room, DateTime from, DateTime to)
    {
        var reservation = new Reservation(room.Number, Username, from, to, ReservationStatus.Activa);

        Reservations.Add(reservation);
        room.SetStatus(RoomStatus.Ocupata);

        Console.WriteLine($"Rezervarea camerei {room.Number} a fost realizata.");
    }
    //Functie de anulare a unei rezervari
    public void CancelReservation(Reservation reservation, Room room)
    {
        reservation.SetStatus(ReservationStatus.Anulata);
        room.SetStatus(RoomStatus.Libera);

        Console.WriteLine($"Rezervarea camerei {room.Number} a fost anulata.");
    }
    //Functie ce permite utilizatorului sa faca check-in
    public void CheckIn(Reservation reservation)
    {
        Console.WriteLine($"Check-in realizat pentru camera {reservation.RoomNumber}.");
    }
    //Functie ce permite utilizatorului sa faca check-out
    public void CheckOut(Reservation reservation, Room room)
    {
        reservation.SetStatus(ReservationStatus.Finalizata);
        room.SetStatus(RoomStatus.Libera);

        Console.WriteLine($"check-out realizat pentru camera {reservation.RoomNumber}.");
    }
    //Functie ce arata rezervariile curente
    public void ShowReservations()
    {
        Console.WriteLine("Rezervarile tale: ");
        foreach (var r in Reservations)
            Console.WriteLine($"Camera {r.RoomNumber}, Status: {r.Status}, {r.From:dd/MM/yyyy} - {r.To:dd/MM/yyyy}");
    }
    //Functie ce modifica datele unei rezervari (calendaristice(
    public void ModifyReservationDates(Reservation reservation, DateTime newFrom, DateTime newTo)
    {
        reservation.UpdateDates(newFrom, newTo);
        Console.WriteLine(
            $"Rezervarea camerei {reservation.RoomNumber} a fost modificata: {newFrom:dd/MM/yyyy} - {newTo:dd/MM/yyyy}");
    }
    //Functie ce arata istoricul de rezervari
    public void ShowHistory()
    {
        Console.WriteLine("Istoric sejururi finalizate: ");
        foreach (var r in Reservations)
            if (r.Status == ReservationStatus.Finalizata)
                Console.WriteLine($"Camera {r.RoomNumber}, {r.From:dd/MM/yyyy} - {r.To:dd/MM/yyyy}");
    }
}