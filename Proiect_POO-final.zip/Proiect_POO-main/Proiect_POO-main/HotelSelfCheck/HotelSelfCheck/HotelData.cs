namespace HotelSelfCheck;

public class HotelData
{
    //Container principal pentru datele aplicatiei (camere, rezervari, utilizatori, reguli)
    public List<Room> Rooms { get; set; } = new();
    public List<Reservation> Reservations { get; set; } = new();
    public List<User> Users { get; set; } = new();

    //Functie de initializare a datelor. In cazul in care nu exista utilizatori, se creeaza utilizatori default 
    public void InitializeDefaults()
    {
        if (Rooms == null) Rooms = new List<Room>();
        if (Reservations == null) Reservations = new List<Reservation>();
        if (Users == null) Users = new List<User>();

        if (!Users.Any(u => u.Username.Equals("admin", StringComparison.OrdinalIgnoreCase)))
            Users.Add(new User(1, "admin", "admin", UserType.Admin));

        if (!Users.Any(u => u.Username.Equals("client", StringComparison.OrdinalIgnoreCase)))
            Users.Add(new Client(2, "client", "1234"));
    }
}